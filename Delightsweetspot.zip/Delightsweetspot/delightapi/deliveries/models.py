from django.db import models

class Delivery(models.Model):
    customer_name = models.CharField(max_length=100)
    address = models.TextField()
    item = models.CharField(max_length=100)
    status = models.CharField(max_length=50, default='Pending')

    def __str__(self):
        return f"{self.customer_name} - {self.item}"


# Create your models here.
