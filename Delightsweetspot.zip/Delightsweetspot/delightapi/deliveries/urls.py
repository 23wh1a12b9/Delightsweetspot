from django.urls import path
from . import views

urlpatterns = [
    path('deliveries/', views.delivery_list, name='delivery-list'),
    path('deliveries/<int:pk>/', views.delivery_detail, name='delivery-detail'),
]

